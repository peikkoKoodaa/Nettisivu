#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_EASY_FONT_IMPLEMENTATION
#include "stb_easy_font.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <limits>
#include <algorithm>
#include <functional>
#include <cmath>
#include <string>
#include <map>
#include <random>
#include <filesystem>

#include "Shader.h"

using namespace std;

const unsigned int SCR_WIDTH = 1000;
const unsigned int SCR_HEIGHT = 800;

int ylosalas = 0;

unsigned int squareVAO = 0;
unsigned int squareVBO = 0;

struct Character {
    unsigned int TextureID;
    glm::ivec2 Size;     
    glm::ivec2 Bearing;  
    unsigned int Advance;
};

struct Vec3iHash {
    size_t operator()(const glm::ivec3& v) const noexcept {
        size_t hx = std::hash<int>()(v.x);
        size_t hy = std::hash<int>()(v.y);
        size_t hz = std::hash<int>()(v.z);
        size_t res = hx;
        res ^= (hy + 0x9e3779b97f4a7c15ULL + (res<<6) + (res>>2));
        res ^= (hz + 0x9e3779b97f4a7c15ULL + (res<<6) + (res>>2));
        return res;
    }
};
struct Vec3iEq {
    bool operator()(const glm::ivec3& a, const glm::ivec3& b) const noexcept {
        return a.x == b.x && a.y == b.y && a.z == b.z;
    }
};

glm::vec3 cameraPos(0.0f, 2.0f, 5.0f);
glm::vec3 cameraFront(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp(0.0f, 1.0f, 0.0f);
float lastX = 500.0f, lastY = 400.0f;
bool firstMouse = true;
float yaw = -90.0f, pitch = 0.0f;
float sensitivity = 0.16f;

bool needUpdateInstances = true;

void mouse_callback(GLFWwindow* /*window*/, double xpos, double ypos) {
    if (firstMouse) { lastX = (float)xpos; lastY = (float)ypos; firstMouse = false; }
    float xoffset = float(xpos - lastX);
    float yoffset = float(lastY - ypos);
    lastX = (float)xpos; lastY = (float)ypos;
    xoffset *= sensitivity; yoffset *= sensitivity;
    yaw += xoffset; pitch += yoffset;
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

bool RaycastVoxel(const glm::vec3& ro, const glm::vec3& rd_norm,
                  const unordered_set<glm::ivec3, Vec3iHash, Vec3iEq>& cubeSet,
                  float maxDistance,
                  glm::ivec3& outPointed, glm::vec3& outHitPos, string& outFace)
{
    if (glm::any(glm::isnan(ro)) || glm::any(glm::isnan(rd_norm))) return false;
    const float EPS = 1e-6f;
    if (glm::length(rd_norm) <= EPS) return false;
    if (maxDistance <= 0.0f) return false;

    const float INF = numeric_limits<float>::infinity();

    glm::ivec3 current(
        static_cast<int>(floor(ro.x + 0.5f)),
        static_cast<int>(floor(ro.y + 0.5f)),
        static_cast<int>(floor(ro.z + 0.5f))
    );

    if (cubeSet.find(current) != cubeSet.end()) {
        outPointed = current;
        outHitPos = ro;
        outFace = "inside";
        return true;
    }

    int stepX = (rd_norm.x > 0.0f) ? 1 : (rd_norm.x < 0.0f ? -1 : 0);
    int stepY = (rd_norm.y > 0.0f) ? 1 : (rd_norm.y < 0.0f ? -1 : 0);
    int stepZ = (rd_norm.z > 0.0f) ? 1 : (rd_norm.z < 0.0f ? -1 : 0);

    if (stepX == 0 && stepY == 0 && stepZ == 0) return false;

    float tMaxX = INF, tMaxY = INF, tMaxZ = INF;
    float tDeltaX = INF, tDeltaY = INF, tDeltaZ = INF;

    if (stepX != 0) {
        float nextBoundary = (current.x + (stepX > 0 ? 0.5f : -0.5f));
        tMaxX = (nextBoundary - ro.x) / rd_norm.x;
        if (tMaxX < 0.0f) tMaxX = 0.0f;
        tDeltaX = 1.0f / std::fabs(rd_norm.x);
    }
    if (stepY != 0) {
        float nextBoundary = (current.y + (stepY > 0 ? 0.5f : -0.5f));
        tMaxY = (nextBoundary - ro.y) / rd_norm.y;
        if (tMaxY < 0.0f) tMaxY = 0.0f;
        tDeltaY = 1.0f / std::fabs(rd_norm.y);
    }
    if (stepZ != 0) {
        float nextBoundary = (current.z + (stepZ > 0 ? 0.5f : -0.5f));
        tMaxZ = (nextBoundary - ro.z) / rd_norm.z;
        if (tMaxZ < 0.0f) tMaxZ = 0.0f;
        tDeltaZ = 1.0f / std::fabs(rd_norm.z);
    }

    float t = 0.0f;

    while (t <= maxDistance) {
        if (tMaxX <= tMaxY && tMaxX <= tMaxZ) {
            current.x += stepX;
            t = tMaxX;
            tMaxX += tDeltaX;
            if (t > maxDistance) break;
            if (cubeSet.find(current) != cubeSet.end()) {
                outPointed = current;
                outHitPos = ro + rd_norm * t;
                outFace = (stepX > 0) ? "west" : "east";
                return true;
            }
        } else if (tMaxY <= tMaxX && tMaxY <= tMaxZ) {
            current.y += stepY;
            t = tMaxY;
            tMaxY += tDeltaY;
            if (t > maxDistance) break;
            if (cubeSet.find(current) != cubeSet.end()) {
                outPointed = current;
                outHitPos = ro + rd_norm * t;
                outFace = (stepY > 0) ? "bottom" : "top";
                return true;
            }
        } else {
            current.z += stepZ;
            t = tMaxZ;
            tMaxZ += tDeltaZ;
            if (t > maxDistance) break;
            if (cubeSet.find(current) != cubeSet.end()) {
                outPointed = current;
                outHitPos = ro + rd_norm * t;
                outFace = (stepZ > 0) ? "south" : "north";
                return true;
            }
        }
    }

    return false;
}

unsigned int loadTexture(const char* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int w, h, comp;
    unsigned char* data = stbi_load(path, &w, &h, &comp, 4);
    if(!data) {
        std::cout << "TEXTURE FAIL " << path << "\n";
        return 0;
    }

    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    stbi_image_free(data);
    return textureID;
}

void initNelio() {
    glGenVertexArrays(1, &squareVAO);
    glGenBuffers(1, &squareVBO);

    glBindVertexArray(squareVAO);
    glBindBuffer(GL_ARRAY_BUFFER, squareVBO);

    glBufferData(GL_ARRAY_BUFFER, 6 * 4 * sizeof(float), nullptr, GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void initNelio();
void drawNelio(GLFWwindow* window, float x, float y, float korkeus, float leveys) {
    float vertices[] = {
        x, y,         0.0f, 0.0f,
        x + leveys, y, 1.0f, 0.0f,
        x, y + korkeus, 0.0f, 1.0f,

        x + leveys, y + korkeus, 1.0f, 1.0f,
        x, y + korkeus, 0.0f, 1.0f,
        x + leveys, y, 1.0f, 0.0f
    };

    glBindVertexArray(squareVAO);
    glBindBuffer(GL_ARRAY_BUFFER, squareVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);

    glDrawArrays(GL_TRIANGLES, 0, 6);
}
GLuint squareVAO_lines, squareVBO_lines;

void initNelioViivat() {
    glGenVertexArrays(1, &squareVAO_lines);
    glGenBuffers(1, &squareVBO_lines);

    glBindVertexArray(squareVAO_lines);
    glBindBuffer(GL_ARRAY_BUFFER, squareVBO_lines);

    glBufferData(GL_ARRAY_BUFFER, 4 * 2 * sizeof(float), nullptr, GL_DYNAMIC_DRAW); // 4 vertex * 2 float

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void initNelioViivat();
void drawNelioViivat(float x, float y, float leveys, float korkeus) {
    float vertices[] = {
        x, y,       
        x + leveys, y,    
        x + leveys, y + korkeus,
        x, y + korkeus 
    };

    glBindVertexArray(squareVAO_lines);
    glBindBuffer(GL_ARRAY_BUFFER, squareVBO_lines);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
    glBindVertexArray(squareVAO_lines);
    glDrawArrays(GL_LINE_LOOP, 0, 4);
    glBindVertexArray(0); 
}

void scrollaus(GLFWwindow* window, double xoffset, double yoffset) {
    ylosalas = yoffset;
}

// VAIHDA TEKSTUURIPACKIT TÄNNE!!
std::vector<std::filesystem::path> assetRoots = {
    "textures",
    "resourcepacks/betterPixels"
};

std::filesystem::path findTexture(const std::string& relativePath) {
    for (const auto& root : assetRoots) {
        auto full = root / relativePath;
        std::cout << "[DEBUG] Trying: " << full << "\n";
        if (std::filesystem::exists(full)) {
            std::cout << "[DEBUG] Found: " << full << "\n";
            return full;
        }
    }
    throw std::runtime_error("Texture not found: " + relativePath);
}

std::unordered_map<std::string, GLuint> textureCache;

GLuint getTexture(const char* virtualPath) {
    auto it = textureCache.find(virtualPath);
    if (it != textureCache.end()) {
        return it->second;
    }

    GLuint tex;
    try {
        tex = loadTexture(findTexture(virtualPath).c_str());
    } catch (const std::runtime_error& e) {
        std::cout << e.what() << "\n";
        tex = 0;
    }

    textureCache[virtualPath] = tex;
    return tex;
}

int main() {
    if (!glfwInit()) { cerr << "GLFW init failed\n"; return -1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(1000, 800, "3D Minecraft 2.5", nullptr, nullptr);
    if (!window) { cerr << "Window creation failed\n"; glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) { cerr << "GLAD init failed\n"; return -1; }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Vertex Shader
    const char* vs = R"(
    #version 330 core
    layout(location=0) in vec3 aPos;
    layout(location=3) in vec2 aUV;
    layout(location=1) in vec3 aInstancePos;
    layout(location=2) in vec4 aInstanceCol;

    uniform mat4 view;
    uniform mat4 projection;
    uniform mat4 model;
    uniform bool useInstancing;

    out vec4 vColor;
    out vec2 vUV;

    void main() {
        vec4 worldPos = vec4(aPos,1.0);
        if(useInstancing){
            worldPos.xyz += aInstancePos;
            vColor = aInstanceCol;
        } else {
            worldPos = model * worldPos;
            vColor = vec4(1.0);
        }
        vUV = aUV;
        gl_Position = projection * view * worldPos;
    }
    )";

    // Fragment Shader
    const char* fs = R"(
    #version 330 core
    in vec4 vColor;
    in vec2 vUV;

    uniform sampler2D tex;
    uniform bool useTexture;
    uniform vec4 overrideColor;

    out vec4 FragColor;

    void main(){
        if(overrideColor.a > 0.0){
            FragColor = overrideColor;
            return;
        }
        if(useTexture){
            FragColor = texture(tex, vUV);
        } else {
            FragColor = vColor;
        }
    }
    )";

    const char* tahtainFS = R"(
    #version 330 core

    out vec4 FragColor;
    void main(){
        FragColor = vec4(0.0,0.0,0.0,1.0);
    }
    )";

    const char* tahtainVS = R"(
    #version 330 core

    layout(location=0) in vec2 aPos;
    void main(){
        gl_Position = vec4(aPos,0.0,1.0);
    }
    )";

    const char* barVS = R"(
    #version 330 core
    layout(location = 0) in vec2 aPos;
    layout(location = 1) in vec2 aTex;

    out vec2 TexCoord;

    void main() {
        gl_Position = vec4(aPos, 0.0, 1.0);
        TexCoord = aTex;
    }
    )";

    const char* barFS = R"(
    #version 330 core
    out vec4 FragColor;
    in vec2 TexCoord;

    uniform sampler2D tex;
    uniform bool useTexture;
    uniform vec4 overrideColor;

    void main() {
        if(useTexture)
            FragColor = texture(tex, TexCoord);
        else
            FragColor = overrideColor;
    }
    )";

    Shader shader(vs, fs);
    shader.use();
    initNelio();
    initNelioViivat();

    float cubeVerts[] = {
        // FRONT
        -0.5f,-0.5f,0.5f,   0.0f,0.0f,
        0.5f,-0.5f,0.5f,   1.0f,0.0f,
        0.5f, 0.5f,0.5f,   1.0f,1.0f,

        0.5f, 0.5f,0.5f,   1.0f,1.0f,
        -0.5f, 0.5f,0.5f,   0.0f,1.0f,
        -0.5f,-0.5f,0.5f,   0.0f,0.0f,

        // BACK
        -0.5f,-0.5f,-0.5f,  1.0f,0.0f,
        -0.5f, 0.5f,-0.5f,  1.0f,1.0f,
        0.5f, 0.5f,-0.5f,  0.0f,1.0f,

        0.5f, 0.5f,-0.5f,  0.0f,1.0f,
        0.5f,-0.5f,-0.5f,  0.0f,0.0f,
        -0.5f,-0.5f,-0.5f,  1.0f,0.0f,

        // LEFT
        -0.5f,-0.5f,-0.5f,  0.0f,0.0f,
        -0.5f,-0.5f, 0.5f,  1.0f,0.0f,
        -0.5f, 0.5f, 0.5f,  1.0f,1.0f,

        -0.5f, 0.5f, 0.5f,  1.0f,1.0f,
        -0.5f, 0.5f,-0.5f,  0.0f,1.0f,
        -0.5f,-0.5f,-0.5f,  0.0f,0.0f,

        // RIGHT
        0.5f,-0.5f,-0.5f,  1.0f,0.0f,
        0.5f, 0.5f,-0.5f,  1.0f,1.0f,
        0.5f, 0.5f, 0.5f,  0.0f,1.0f,

        0.5f, 0.5f, 0.5f,  0.0f,1.0f,
        0.5f,-0.5f, 0.5f,  0.0f,0.0f,
        0.5f,-0.5f,-0.5f,  1.0f,0.0f,

        // TOP
        -0.5f, 0.5f,-0.5f,  0.0f,1.0f,
        -0.5f, 0.5f, 0.5f,  0.0f,0.0f,
        0.5f, 0.5f, 0.5f,  1.0f,0.0f,

        0.5f, 0.5f, 0.5f,  1.0f,0.0f,
        0.5f, 0.5f,-0.5f,  1.0f,1.0f,
        -0.5f, 0.5f,-0.5f,  0.0f,1.0f,

        // BOTTOM
        -0.5f,-0.5f,-0.5f,  0.0f,0.0f,
        0.5f,-0.5f,-0.5f,  1.0f,0.0f,
        0.5f,-0.5f, 0.5f,  1.0f,1.0f,

        0.5f,-0.5f, 0.5f,  1.0f,1.0f,
        -0.5f,-0.5f, 0.5f,  0.0f,1.0f,
        -0.5f,-0.5f,-0.5f,  0.0f,0.0f
    };

    unsigned int dirtTexture = getTexture("multa.png");
    unsigned int grassTexture = getTexture("ruoho.png");
    unsigned int stoneTexture = getTexture("kivi.png");
    unsigned int woodTexture = getTexture("puu.png");
    unsigned int logTexture = getTexture("puuhalko.png");
    unsigned int goldTexture = getTexture("kultamalmi.png");
    unsigned int darkWoodTexture = getTexture("tummapuu.png");

    int index = 1;

    unsigned int VAO, VBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts, GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(
        0,
        3,
        GL_FLOAT,
        GL_FALSE,
        5 * sizeof(float),      
        (void*)0
    );

    glEnableVertexAttribArray(3);
    glVertexAttribPointer(
        3,
        2,
        GL_FLOAT,
        GL_FALSE,
        5 * sizeof(float),
        (void*)(3 * sizeof(float))
    );

    unsigned int instanceVBO_pos, instanceVBO_col;
    glGenBuffers(1, &instanceVBO_pos);
    glGenBuffers(1, &instanceVBO_col);

    const size_t INITIAL_CAP = 20000;

    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_pos);
    glBufferData(GL_ARRAY_BUFFER, INITIAL_CAP * sizeof(glm::vec3), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), (void*)0);
    glVertexAttribDivisor(1, 1);

    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_col);
    glBufferData(GL_ARRAY_BUFFER, INITIAL_CAP * sizeof(glm::vec4), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(glm::vec4), (void*)0);
    glVertexAttribDivisor(2, 1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    unsigned int cubeVAO_single;
    glGenVertexArrays(1, &cubeVAO_single);
    glBindVertexArray(cubeVAO_single);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);

    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

    glBindVertexArray(0);

    float radius = 0.02f;
    const int segments = 32;
    vector<glm::vec2> verts;
    for(int i=0;i<segments;i++){
        float theta = 2.0f * 3.1415926f * i / segments;
        verts.push_back(glm::vec2(cos(theta)*radius, sin(theta)*radius));
    }

    unsigned int vao, vbo;
    glGenVertexArrays(1,&vao);
    glGenBuffers(1,&vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER,vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size()*sizeof(glm::vec2), verts.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(glm::vec2),(void*)0);
    glBindVertexArray(0);

    unordered_set<glm::ivec3, Vec3iHash, Vec3iEq> cubeSet;
    unordered_map<glm::ivec3, glm::vec4, Vec3iHash, Vec3iEq> cubeColors;

    const int SX = 25;
    const int SZ = 25;

    unordered_set<glm::ivec3, Vec3iHash, Vec3iEq> gold;

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(50, 100);

    int maara = dis(gen);

    uniform_int_distribution<> distY(-14, -5);
    uniform_int_distribution<> distX(0, SX-1);
    uniform_int_distribution<> distZ(0, SZ-1);

    for (int i = 0; i < maara; i++) {
        int goldX = distX(gen);
        int goldY = distY(gen);
        int goldZ = distZ(gen);

        gold.insert(glm::ivec3(goldX, goldY, goldZ));
    }

    for(int x=0;x<SX;++x)
        for(int z=0; z<SZ; ++z)
            cubeSet.insert(glm::ivec3(x,0,z));
    for(int x=0;x<SX;++x)
        for(int y=-1; y>=-4; --y)
            for(int z=0; z<SZ; ++z)
                cubeSet.insert(glm::ivec3(x,y,z));
    for(int x=0;x<SX;++x)
        for(int y=-5; y>=-14; --y)
            for(int z=0; z<SZ; ++z)
                cubeSet.insert(glm::ivec3(x,y,z));

    for(const auto &c : cubeSet) {
        if(c.y >= 0) cubeColors[c] = glm::vec4(0.0f, 1.0f, 0.0f,1.0f);
        else if(c.y > -5) cubeColors[c] = glm::vec4(0.5f,0.2f,0.2f,1.0f);
        else cubeColors[c] = glm::vec4(0.5f,0.5f,0.5f,1.0f);
    }

    vector<glm::vec3> instPos;
    vector<glm::vec4> instCol;
    instPos.reserve(10000);
    instCol.reserve(10000);
    GLsizei instanceCount = 0;

    bool escPressed = false;
    bool rightMousePrev = false;
    bool leftMousePrev = false;
    float maxRayDistance = 8.0f;
    std::string blokki = "puu";

    float blokkiX = -0.95f;

    Shader circleShader(tahtainVS,tahtainFS);
    Shader barShader(barVS, barFS);

    glm::mat4 ortho = glm::ortho(0.0f, 1000.0f, 0.0f, 800.0f);

    glm::vec3 textColor(0.0f, 0.0f, 0.0f);

    std::string palikkateksti = "palikka: puu";

    float textX = 10.0f;
    float textY = 10.0f;

    std::vector<unsigned int> instTex;
    instTex.reserve(INITIAL_CAP);

    unsigned int instanceVBO_tex;
    glGenBuffers(1, &instanceVBO_tex);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_tex);
    glBufferData(GL_ARRAY_BUFFER, INITIAL_CAP * sizeof(unsigned int), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(4);
    glVertexAttribIPointer(4, 1, GL_UNSIGNED_INT, sizeof(unsigned int), (void*)0);
    glVertexAttribDivisor(4, 1);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    std::unordered_map<glm::ivec3, std::string, Vec3iHash, Vec3iEq> cubeType;

    std::unordered_map<glm::ivec3, unsigned int, Vec3iHash, Vec3iEq> cubeTexture;
    for(const auto &c : cubeSet) {
        if (gold.find(c) != gold.end()) {
            cubeType[c] = "kulta";
            cubeTexture[c] = goldTexture;
        } else if(c.y >= 0) {
            cubeType[c] = "ruoho";
            cubeTexture[c] = grassTexture;
        } else if(c.y > -5) {
            cubeType[c] = "multa";
            cubeTexture[c] = dirtTexture;
        } else {
            cubeType[c] = "kivi";
            cubeTexture[c] = stoneTexture;
        }
    }

    std::unordered_map<std::string, unsigned int> blockTextures;
    blockTextures["puu"] = woodTexture;
    blockTextures["ruoho"] = grassTexture;
    blockTextures["multa"] = dirtTexture;
    blockTextures["kivi"] = stoneTexture;
    blockTextures["halko"] = logTexture;
    blockTextures["kulta"] = goldTexture;
    blockTextures["tummapuu"] = darkWoodTexture;

    glfwSetScrollCallback(window, scrollaus);

    float speed = 0.12f;

    while(!glfwWindowShouldClose(window)) {

        if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) cameraPos += speed * cameraFront;
        if(glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) cameraPos -= speed * cameraFront;
        if(glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) cameraPos -= glm::normalize(glm::cross(cameraFront,cameraUp))*speed;
        if(glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) cameraPos += glm::normalize(glm::cross(cameraFront,cameraUp))*speed;
        if(glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) cameraPos += speed * cameraUp;
        if(glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) cameraPos -= speed * cameraUp;
        
        if(glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {index = 1;}
        if(glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) {index = 2;}
        if(glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS) {index = 3;}
        if(glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS) {index = 4;}
        if(glfwGetKey(window, GLFW_KEY_5) == GLFW_PRESS) {index = 5;}
        if(glfwGetKey(window, GLFW_KEY_6) == GLFW_PRESS) {index = 6;}
        if(glfwGetKey(window, GLFW_KEY_7) == GLFW_PRESS) {index = 7;}
        if(glfwGetKey(window, GLFW_KEY_8) == GLFW_PRESS) {index = 8;}

        if (ylosalas != 0) {
            if (ylosalas == -1) {
                index += 1;
            }
            if (ylosalas == 1) {
                index -= 1;
            }
        } 

        if(index < 1) index = 8;
        if(index > 8) index = 1;
        if(index == 1) {blokki = "puu"; blokkiX = -0.95f;}
        if(index == 2) {blokki = "ruoho";blokkiX = -0.80f;}
        if(index == 3) {blokki = "multa";blokkiX = -0.65f;}
        if(index == 4) {blokki = "kivi";blokkiX = -0.50f;}
        if(index == 5) {blokki = "lasi";blokkiX = -0.35f;}
        if(index == 6) {blokki = "halko";blokkiX = -0.20f;}
        if(index == 7) {blokki = "kulta"; blokkiX = -0.05f;}
        if(index == 8) {blokki = "tummapuu"; blokkiX = 0.10;}
        ylosalas = 0;

        if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS && !escPressed) {
            escPressed = true;
            if(glfwGetInputMode(window, GLFW_CURSOR) == GLFW_CURSOR_DISABLED)
                glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
            else
                glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        }
        if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_RELEASE) escPressed = false;

        glm::vec3 rd = glm::normalize(cameraFront);
        glm::ivec3 pointed(0);
        bool found = false;
        glm::vec3 hitPos(0.0f);
        string face = "";
        found = RaycastVoxel(cameraPos, rd, cubeSet, maxRayDistance, pointed, hitPos, face);

        bool rightMouseNow = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS;
        if(rightMouseNow && !rightMousePrev && found) {
            glm::ivec3 offset(0);
            if(face=="top") offset = glm::ivec3(0,1,0);
            else if(face=="bottom") offset = glm::ivec3(0,-1,0);
            else if(face=="north") offset = glm::ivec3(0,0,1);
            else if(face=="south") offset = glm::ivec3(0,0,-1);
            else if(face=="east") offset = glm::ivec3(1,0,0);
            else if(face=="west") offset = glm::ivec3(-1,0,0);

            glm::ivec3 place = pointed + offset;
            if(cubeSet.find(place) == cubeSet.end()) {
                cubeSet.insert(place);
                if (blokki == "puu") {    
                    cubeColors[place] = glm::vec4(0.7f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "ruoho") {
                    cubeColors[place] = glm::vec4(0.0f,1.0f,0.0f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "multa") {
                    cubeColors[place] = glm::vec4(0.5f,0.2f,0.2f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "kivi") {
                    cubeColors[place] = glm::vec4(0.5f,0.5f,0.5f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "lasi") {
                    cubeColors[place] = glm::vec4(0.9f,0.9f,1.0f,0.4f);
                    cubeType[place] = blokki;
                } else if (blokki == "halko") {
                    cubeColors[place] = glm::vec4(0.7f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "kulta") {
                    cubeColors[place] = glm::vec4(0.7f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "tummapuu") {
                    cubeColors[place] = glm::vec4(0.8f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "kalterit") {
                    cubeColors[place] = glm::vec4(0.8f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                } else if (blokki == "tikkaat") {
                    cubeColors[place] = glm::vec4(0.8f,0.3f,0.1f,1.0f);
                    cubeType[place] = blokki;
                }    
                needUpdateInstances = true;
            }
        }
        rightMousePrev = rightMouseNow;

        bool leftMouseNow = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
        if(leftMouseNow && !leftMousePrev && found) {
            cubeSet.erase(pointed);
            cubeColors.erase(pointed);
            needUpdateInstances = true;
        }
        leftMousePrev = leftMouseNow;

        if(needUpdateInstances) {
            instPos.clear();
            instCol.clear();
            instTex.clear();
            instPos.reserve(cubeSet.size());
            instCol.reserve(cubeSet.size());

            for(const auto &c : cubeSet) {
                glm::vec3 cf = glm::vec3(c);
                instPos.push_back(cf);

                if(found && c == pointed) {
                    auto it = cubeColors.find(c);
                    instCol.push_back(it->second);
                } else {
                    auto it = cubeColors.find(c);
                    if(it != cubeColors.end())
                        instCol.push_back(it->second);
                    else if (gold.find(c) != gold.end()) {
                        instPos.push_back(glm::vec3(c));
                        instCol.push_back(glm::vec4(1.0f));
                        instTex.push_back(cubeTexture[c]);    
                    }    
                    else if(c.y >= 0) {
                        instPos.push_back(glm::vec3(c));
                        instCol.push_back(glm::vec4(1.0f));
                        instTex.push_back(cubeTexture[c]); 
                    } else if(c.y > -5) {
                        instPos.push_back(glm::vec3(c));
                        instCol.push_back(glm::vec4(1.0f));
                        instTex.push_back(cubeTexture[c]); 
                    } else {
                        instPos.push_back(glm::vec3(c));
                        instCol.push_back(glm::vec4(1.0f));
                        instTex.push_back(cubeTexture[c]);   
                    }
                }
            }

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_pos);
            glBufferData(GL_ARRAY_BUFFER, instanceCount * sizeof(glm::vec3), instPos.data(), GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_col);
            glBufferData(GL_ARRAY_BUFFER, instanceCount * sizeof(glm::vec4), instCol.data(), GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_tex);
            glBufferData(GL_ARRAY_BUFFER, instanceCount * sizeof(unsigned int), instTex.data(), GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, 0);

            instanceCount = (GLsizei)instPos.size();

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_pos);
            glBufferData(GL_ARRAY_BUFFER, instanceCount * sizeof(glm::vec3), instPos.data(), GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_col);
            glBufferData(GL_ARRAY_BUFFER, instanceCount * sizeof(glm::vec4), instCol.data(), GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, 0);

            needUpdateInstances = false;
        }

        // --- Rakennetaan instancing-listat: erota opaque ja transparent ---
        instPos.clear();
        instCol.clear();
        instPos.reserve(cubeSet.size());
        instCol.reserve(cubeSet.size());

        // --- Erotellaan opaque ja transparent kuutiot ---
        std::vector<glm::ivec3> opaqueList;
        std::vector<std::pair<float, glm::ivec3>> transparentList;

        for(const auto &c : cubeSet) {
            glm::vec4 color = cubeColors.count(c) ? cubeColors[c] : glm::vec4(0.0f,1.0f,0.0f,1.0f);
            if(color.a >= 1.0f)
                opaqueList.push_back(c);
            else {
                float dist = glm::length(cameraPos - glm::vec3(c));
                transparentList.push_back({dist, c});
            }
        }

        glClearColor(0.4f,0.6f,0.9f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glm::mat4 proj = glm::perspective(glm::radians(70.0f), 1000.0f/800.0f, 0.1f, 200.0f);

        shader.use();
        shader.setMat4("view", view);
        shader.setMat4("projection", proj);
        shader.setBool("useInstancing", true);
        shader.setBool("useTexture", true);
        shader.setVec4("overrideColor", glm::vec4(0,0,0,0));

        for(auto &[name, tex] : blockTextures){
            std::vector<glm::vec3> positions;
            std::vector<glm::vec4> colors;

            for(auto &c : cubeSet){
                glm::vec4 col = cubeColors[c];
                if(col.a >= 1.0f && cubeType[c] == name){
                    positions.push_back(glm::vec3(c));
                    colors.push_back(col);
                }
            }

            if(positions.empty()) continue;

            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_pos);
            glBufferData(GL_ARRAY_BUFFER, positions.size()*sizeof(glm::vec3), positions.data(), GL_DYNAMIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER, instanceVBO_col);
            glBufferData(GL_ARRAY_BUFFER, colors.size()*sizeof(glm::vec4), colors.data(), GL_DYNAMIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER,0);

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, tex);
            shader.setInt("tex",0);

            glBindVertexArray(VAO);
            glDrawArraysInstanced(GL_TRIANGLES, 0, 36, (GLsizei)positions.size());
            glBindVertexArray(0);
        }

        // --- 2) Draw transparent (FAR->NEAR) ---
        if(!transparentList.empty()) {
            std::sort(transparentList.begin(), transparentList.end(),
                    [](auto &a, auto &b){ return a.first > b.first; }); // FAR->NEAR

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(GL_FALSE);

            shader.setBool("useInstancing", false);

            for(auto &entry : transparentList) {
                glm::ivec3 c = entry.second;
                glm::vec4 col = cubeColors[c];

                glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(c));
                shader.setMat4("model", model);
                shader.setVec4("overrideColor", col);

                glBindVertexArray(cubeVAO_single);
                glDrawArrays(GL_TRIANGLES, 0, 36);
                glBindVertexArray(0);
            }

            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }

        // --- 3) Highlight / UI ---
        if(found) {
            shader.setBool("useInstancing", false);
            glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(pointed));
            model = glm::scale(model, glm::vec3(1.02f));
            shader.setMat4("model", model);
            shader.setVec4("overrideColor", glm::vec4(1.0f,1.0f,1.0f,0.5f));

            glBindVertexArray(cubeVAO_single);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            glBindVertexArray(0);
        }    

        glDisable(GL_DEPTH_TEST);
        circleShader.use();
        glBindVertexArray(vao);
        glDrawArrays(GL_LINE_LOOP, 0, segments);
        glBindVertexArray(0);

        // TavaraBar
        float barThingX = -0.95f;
        glActiveTexture(GL_TEXTURE0);
        barShader.use();
        barShader.setInt("tex", 0);
        barShader.setBool("useTexture", true);
        glDisable(GL_DEPTH_TEST);
        barShader.setBool("useTexture", false);
        barShader.setVec4("overrideColor", glm::vec4(0.5f,0.5f,0.5f,0.5f));
        drawNelio(window, -1.0f, -1.0f, 0.25f, 1.3f);
        barShader.setBool("useTexture", true);
        glBindTexture(GL_TEXTURE_2D, woodTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        glBindTexture(GL_TEXTURE_2D, grassTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        glBindTexture(GL_TEXTURE_2D, dirtTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        glBindTexture(GL_TEXTURE_2D, stoneTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        barShader.setBool("useTexture", false);
        barShader.setVec4("overrideColor", glm::vec4(1.0f,1.0f,1.0f,1.0f));
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        barShader.setBool("useTexture", true);
        glBindTexture(GL_TEXTURE_2D, logTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        glBindTexture(GL_TEXTURE_2D, goldTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;
        glBindTexture(GL_TEXTURE_2D, darkWoodTexture);
        drawNelio(window, barThingX, -0.95f, 0.1f, 0.1f);
        barThingX += 0.15;

        barShader.setBool("useTexture", false);
        barShader.setVec4("overrideColor", glm::vec4(0.0f, 0.0f, 0.0f, 1.0f));
        glLineWidth(4.0f);
        drawNelioViivat(blokkiX, -0.95f, 0.1f, 0.1f);
        glLineWidth(1.0f);
        glEnable(GL_DEPTH_TEST);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}