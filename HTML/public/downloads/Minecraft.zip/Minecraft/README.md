## Ennen kun käynnistät!
# 1
- Lataa ensin GLM ja GLFW

- Linux:
sudo apt update
sudo apt install libglfw3-dev libglm-dev

- Windows:
git clone https://github.com/microsoft/vcpkg.git
cd vcpkg
.\bootstrap-vcpkg.bat
.\vcpkg install glfw3 glm
- ja jos käytät VSCodea:
.\vcpkg integrate install

- MacOS:
- Jos et ole asentanut Homebrew:tä
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install glfw
brew install glm

## Nyt käynnistetään peli!
# 2

- Linux:
g++ src/main.cpp src/Shader.cpp src/glad.c -Iinclude -lglfw -lGL -ldl -o peli
./peli

- Windows:
g++ src\main.cpp src\Shader.cpp src\glad.c -Iinclude -Ic:\path\to\vcpkg\installed\x64-windows\include -Lc:\path\to\vcpkg\installed\x64-windows\lib -lglfw3 -lopengl32 -o peli.exe
- Huom: c:\path\to\vcpkg\installed\x64-windows vaihda omaan polkuusi
.\peli.exe

- MacOS:
g++ src/main.cpp src/Shader.cpp src/glad.c -I/opt/homebrew/include -L/opt/homebrew/lib -lglfw -framework OpenGL -o peli
./peli

## Ja nyt pelaamaan!

## Huom.
# Jos haluat lisätä omia tekstuuripackeja niin:
# 1
- Tee kansio resourcepacks-kansioon.
- Laita kaikki tekstuuri-PNGt sinne.
# 2
- Etsi tällainen kohta koodista (/src/main.cpp):

// VAIHDA TEKSTUURIPACKIT TÄNNE!!
std::vector<std::filesystem::path> assetRoots = {
    TÄNNE NE TEKSTUURIPACKKIEN OSOITTEET: "resourcepacks/SEN SINUN PACKIN NIMI" ELI LAITA TÄNNE SE TEKSTUURIPACKKI MINKÄ HALUAT OLEVAN PÄÄLLÄ.
    "textures",
    "resourcepacks/betterPixels"
};
- Tuo "textures" on ne normaalit tekstuurit.