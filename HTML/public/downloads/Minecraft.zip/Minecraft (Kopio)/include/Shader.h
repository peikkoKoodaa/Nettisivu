#ifndef SHADER_H
#define SHADER_H

#include <glad/glad.h>
#include <string>
#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <string>
#include <glad/glad.h>

class Shader {
public:
    unsigned int ID;
    
    Shader(const char* vertexSrc, const char* fragmentSrc);

    void use() { glUseProgram(ID); }

    void setMat4(const std::string &name, const glm::mat4 &mat) const;
    void setVec4(const std::string &name, const glm::vec4 &value) const;
    void setBool(const std::string &name, bool value) const;
    void setVec3(const std::string &name, const glm::vec3 &value) const {
        glUniform3fv(glGetUniformLocation(ID, name.c_str()), 1, glm::value_ptr(value));
    }
    void setInt(const std::string &name, int value) const;
    void setVec2(const std::string &name, const glm::vec2 &value) const;

    void setFloat(const std::string &name, float value) const {
        glUniform1f(glGetUniformLocation(ID, name.c_str()), value);
    }
};

#endif
