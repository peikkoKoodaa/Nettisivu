#include <list>
#include <algorithm>
#include <random>
#include <chrono>
#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "Shader.h"
#include "TextureLoader.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

using namespace std;

glm::vec3 cameraPos   = glm::vec3(2.0f, 2.0f, 2.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 3.0f, 0.0f);
glm::vec3 cameraUp    = glm::vec3(0.0f, 1.0f, 0.0f);


float yaw   = -90.0f;
float pitch = 0.0f;
float lastX = 400, lastY = 300;
bool firstMouse = true;

float deltaTime = 0.0f;
float lastFrame = 0.0f;
float speed = 5.0f;

bool escPressedLastFrame = false;
bool isMouse = false;

void processInput(GLFWwindow* window, const std::vector<std::vector<char>>& maze) {
    float velocity = speed * deltaTime;
    glm::vec3 flatFront = cameraFront;
    flatFront.y = 0.0f;
    flatFront = glm::normalize(flatFront);
    glm::vec3 right = glm::normalize(glm::cross(flatFront, cameraUp));
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        glm::vec3 nextPos = cameraPos + flatFront * velocity;
        int nextX = static_cast<int>(nextPos.x);
        int nextZ = static_cast<int>(nextPos.z);
        if (maze[nextZ][nextX] != '#')
            cameraPos = nextPos;
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        glm::vec3 nextPos = cameraPos - flatFront * velocity;
        int nextX = static_cast<int>(nextPos.x);
        int nextZ = static_cast<int>(nextPos.z);
        if (maze[nextZ][nextX] != '#')
            cameraPos = nextPos;
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        glm::vec3 nextPos = cameraPos - right * velocity;
        int nextX = static_cast<int>(nextPos.x);
        int nextZ = static_cast<int>(nextPos.z);
        if (maze[nextZ][nextX] != '#')
            cameraPos = nextPos;
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        glm::vec3 nextPos = cameraPos + right * velocity;
        int nextX = static_cast<int>(nextPos.x);
        int nextZ = static_cast<int>(nextPos.z);
        if (maze[nextZ][nextX] != '#')
            cameraPos = nextPos;
    }
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS && !escPressedLastFrame) {
        escPressedLastFrame = true;
        isMouse = !isMouse;
        GLFWmonitor* monitor = glfwGetPrimaryMonitor();
        const GLFWvidmode* mode = glfwGetVideoMode(monitor);

        if (isMouse) {
            glfwSetWindowMonitor(window, nullptr, 100, 100, 800, 800, mode->refreshRate);
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        } else {
            glfwSetWindowMonitor(window, monitor, 0, 0, mode->width, mode->height, mode->refreshRate);
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        }
    }
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_RELEASE && escPressedLastFrame)
        escPressedLastFrame = false;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float sensitivity = 0.2f;
    float xoffset = (xpos - lastX) * sensitivity;
    float yoffset = (lastY - ypos) * sensitivity;

    lastX = xpos;
    lastY = ypos;

    yaw   += xoffset;
    pitch += yoffset;

    pitch = glm::clamp(pitch, -89.0f, 89.0f);

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

int WIDTH = 81;
int HEIGHT = 81;
std::vector<std::vector<char>> maze(HEIGHT, std::vector<char>(WIDTH, '#'));
std::mt19937 rng(std::random_device{}());

int cellSize = 2;

void makeMaze(int x, int y) {
    for (int dy=0; dy<cellSize; dy++)
        for (int dx=0; dx<cellSize; dx++)
            maze[y+dy][x+dx] = ' ';
    std::vector<std::pair<int,int>> dirs = {
        {2*cellSize,0}, {-2*cellSize,0}, {0,2*cellSize}, {0,-2*cellSize}
    };
    std::shuffle(dirs.begin(), dirs.end(), rng);
    for (auto [dx, dy] : dirs) {
        int nx = x + dx;
        int ny = y + dy;
        if (nx > 0 && ny > 0 && nx+cellSize-1 < WIDTH-1 && ny+cellSize-1 < HEIGHT-1) {
            bool isWall = true;
            for (int dy2=0; dy2<cellSize; dy2++)
                for (int dx2=0; dx2<cellSize; dx2++)
                    if (maze[ny+dy2][nx+dx2] == ' ')
                        isWall = false;
            if (isWall) {
                for (int dy2=0; dy2<cellSize; dy2++)
                    for (int dx2=0; dx2<cellSize; dx2++)
                        maze[y + dy/2 + dy2][x + dx/2 + dx2] = ' ';
                makeMaze(nx, ny);
            }
        }
    }
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

void drawCube(Shader& shader, unsigned int VAO,
              float x, float y, float z)
{
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(x, y, z));

    shader.setMat4("model", model);

    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, 36);
}

int main() {
    makeMaze(1, 1);

    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW\n";
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWmonitor* monitor = glfwGetPrimaryMonitor();
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);

    GLFWwindow* window = glfwCreateWindow(
        mode->width, mode->height, "3D Maze", monitor, nullptr
    );
    if (!window) {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD\n";
        return -1;
    }

    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    float cubeVertices[] = {
        0,0,1,  0,0,
        1,0,1,  1,0,
        1,1,1,  1,1,
        1,1,1,  1,1,
        0,1,1,  0,1,
        0,0,1,  0,0,
        0,0,0, 0,0,
        1,0,0, 1,0,
        1,1,0, 1,1,
        1,1,0, 1,1,
        0,1,0, 0,1,
        0,0,0, 0,0,
        0,0,0, 0,0,
        0,0,1, 1,0,
        0,1,1, 1,1,
        0,1,1, 1,1,
        0,1,0, 0,1,
        0,0,0, 0,0,
        1,0,0, 0,0,
        1,0,1, 1,0,
        1,1,1, 1,1,
        1,1,1, 1,1,
        1,1,0, 0,1,
        1,0,0, 0,0,
        0,1,0, 0,0,
        1,1,0, 1,0,
        1,1,1, 1,1,
        1,1,1, 1,1,
        0,1,1, 0,1,
        0,1,0, 0,0,
        0,0,0, 0,0,
        1,0,0, 1,0,
        1,0,1, 1,1,
        1,0,1, 1,1,
        0,0,1, 0,1,
        0,0,0, 0,0
    };

    float groundVertices[] = {
        0,-0.01,0, 0,0,
        WIDTH,-0.01,0, 1,0,
        0,-0.01,HEIGHT, 1,1,

        WIDTH,-0.01,HEIGHT, 0,0,
        WIDTH,-0.01,0, 1,0,
        0,-0.01,HEIGHT, 1,1
    };

    unsigned int wallTexture = TextureLoader::loadTexture("assets/Wall.png");
    unsigned int groundTexture = TextureLoader::loadTexture("assets/Ground.png");

    unsigned int cubeVAO, cubeVBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glBindVertexArray(cubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);

    unsigned int groundVAO, groundVBO;
    glGenVertexArrays(1, &groundVAO);
    glGenBuffers(1, &groundVBO);
    glBindVertexArray(groundVAO);
    glBindBuffer(GL_ARRAY_BUFFER, groundVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(groundVertices), groundVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);

    Shader shader("shaders/vertex_shader.glsl", "shaders/fragment_shader.glsl");
    shader.use();
    shader.setInt("texture1", 0);
    glEnable(GL_DEPTH_TEST);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    while (!glfwWindowShouldClose(window)) {
        glfwSetCursorPosCallback(window, mouse_callback);
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        processInput(window, maze);

        glClearColor(0.1f, 0.4f, 0.6f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        shader.use();

        glm::mat4 model = glm::mat4(1.0f);
        glm::mat4 view = glm::lookAt(
            cameraPos,
            cameraPos + cameraFront,
            cameraUp
        );
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        glm::mat4 projection = glm::perspective(
            glm::radians(60.0f),
            float(width) / float(height),
            0.1f,
            100.0f
        );
        shader.setMat4("model", model);
        shader.setMat4("view", view);
        shader.setMat4("projection", projection);

        glBindVertexArray(groundVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, groundTexture);
        shader.use();
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glBindVertexArray(cubeVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, wallTexture);
        shader.use();
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                if (maze[y][x] == '#') {
                    for (int height=0;height<3;height++) {    
                        drawCube(shader, cubeVAO, x, height, y);
                    }    
                }
            }
        }
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteBuffers(1, &cubeVBO);
    glfwTerminate();
    return 0;
}