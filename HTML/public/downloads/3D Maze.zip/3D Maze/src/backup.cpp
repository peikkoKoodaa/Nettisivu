#include <list>
#include <algorithm>
#include <random>
#include <chrono>
#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "Shader.h"
#include "TextureLoader.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

using namespace std;

int WIDTH = 41;
int HEIGHT = 41;
std::vector<std::vector<char>> maze(HEIGHT, std::vector<char>(WIDTH, '#'));
std::mt19937 rng(std::random_device{}());

void makeMaze(int x, int y) {
    maze[y][x] = ' ';

    std::vector<std::pair<int,int>> dirs = {
        {2,0}, {-2,0}, {0,2}, {0,-2}
    };

    std::shuffle(dirs.begin(), dirs.end(), rng);

    for (auto [dx, dy] : dirs) {
        int nx = x + dx;
        int ny = y + dy;

        if (nx > 0 && ny > 0 && nx < WIDTH-1 && ny < HEIGHT-1) {
            if (maze[ny][nx] == '#') {
                maze[y + dy/2][x + dx/2] = ' ';
                makeMaze(nx, ny);
            }
        }
    }
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

void drawWall(Shader& shader, unsigned int VAO,
              float x, float y, float z,
              float length, bool alongX)
{
    glm::mat4 model(1.0f);

    model = glm::translate(model, glm::vec3(x, y, z));

    if (alongX)
        model = glm::scale(model, glm::vec3(length, 1.0f, 1.0f));
    else
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, length));

    shader.setMat4("model", model);

    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

int main() {
    makeMaze(1, 1);

    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW\n";
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "3D Maze", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD\n";
        return -1;
    }

    glViewport(0, 0, 800, 600);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    float wallVertices[] = {
        0, 0, 0,  0, 0,
        0, 6, 0,  0, 1,
        1, 6, 0,  1, 1,

        1, 6, 0,  1, 1,
        1, 0, 0,  1, 0,
        0, 0, 0,  0, 0
    };

    unsigned int wallTexture = TextureLoader::loadTexture("assets/Wall.png");
    unsigned int groundTexture = TextureLoader::loadTexture("assets/Ground.png");

    unsigned int wallVBO, wallVAO;
    glGenVertexArrays(1, &wallVAO);
    glGenBuffers(1, &wallVBO);
    glBindVertexArray(wallVAO);
    glBindBuffer(GL_ARRAY_BUFFER, wallVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(wallVertices), wallVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);

    Shader shader("shaders/vertex_shader.glsl", "shaders/fragment_shader.glsl");
    shader.use();

    while (!glfwWindowShouldClose(window)) {
        glClearColor(0.1f, 0.4f, 0.6f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, wallTexture);
        shader.use();
        drawWall(shader, wallVAO, 0, 0, 0, 5, true);
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &wallVAO);
    glDeleteBuffers(1, &wallVBO);
    glfwTerminate();
    return 0;
}