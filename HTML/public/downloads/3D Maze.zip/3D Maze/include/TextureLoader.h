#pragma once
#include <string>
#include <glad/glad.h>

class TextureLoader {
public:
    static unsigned int loadTexture(const std::string& path);
};