## Tämä on 3D-Labyrinttipeli.
# Ennen kuin pääset pelaamaan, sinun täytyy asentaa kirjastot.

# 1. Asenna kirjastot. (Voit ohittaa tämän vaiheen jos olet ladannut kaikki kirjastot minun Minecraftiini)
- Linux:
sudo apt update
sudo apt install libglm-dev

- Windows (VS Code):
git clone https://github.com/microsoft/vcpkg.git
cd vcpkg
.\bootstrap-vcpkg.bat
.\vcpkg install glm
.\vcpkg integrate install

- MacOS:
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install glm

# 2. Nyt pelaamaan!
- Linux:
make
./peli

- Windows:
make
.\peli.exe

- MacOS:
make
./peli