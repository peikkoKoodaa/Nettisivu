import pygame as ui
from random import shuffle
from sys import exit
from collections import deque

WIDTH = 31
HEIGHT = 31
TIMES_BIGGER = 30

ui.init()
ikkuna = ui.display.set_mode((TIMES_BIGGER*WIDTH, TIMES_BIGGER*HEIGHT))
ui.display.set_caption("Maze 2D")

maze = [["#" for _ in range(WIDTH)] for _ in range(HEIGHT)]

def makeMaze(start_x, start_y):
    stack = [(start_x, start_y)]
    maze[start_y][start_x] = " "

    while stack:
        x, y = stack[-1]
        directions = [(2,0), (-2,0), (0,2), (0,-2)]
        shuffle(directions)
        carved = False
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 < nx < WIDTH-1 and 0 < ny < HEIGHT-1:
                if maze[ny][nx] == "#":
                    maze[y + dy//2][x + dx//2] = " "
                    maze[ny][nx] = " "
                    stack.append((nx, ny))
                    carved = True
                    break
        if not carved:
            stack.pop()

def solveMaze(start, goal):
    queue = deque([start])
    came_from = {start: None}
    while queue:
        x, y = queue.popleft()
        if (x, y) == goal:
            break
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < WIDTH and 0 <= ny < HEIGHT:
                if maze[ny][nx] == " " and (nx, ny) not in came_from:
                    queue.append((nx, ny))
                    came_from[(nx, ny)] = (x, y)
    path = []
    cur = goal
    while cur:
        path.append(cur)
        cur = came_from.get(cur)
    path.reverse()
    return path                                

ai = False
start = (1, 1)
goal = (WIDTH-2, HEIGHT-2)
makeMaze(1, 1)
if ai:
    path = solveMaze(start, goal)
    animate = True
kello = ui.time.Clock()
path_index = 0
px, py = 1, 1
move_delay = 0.01
last_move = 0

while True:
    for event in ui.event.get():
        if event.type == ui.QUIT:
            ui.quit()
            exit()
        if event.type == ui.KEYDOWN:
            if event.key == ui.K_r:
                maze = [["#" for _ in range(WIDTH)] for _ in range(HEIGHT)]
                makeMaze(*start)
                if ai:
                    path = solveMaze(start, goal)
                    animate = True
                path_index = 0
                px, py = 1, 1
                move_delay = 1
            if event.key == ui.K_a:
                ai = not ai
                if ai:
                    path = solveMaze(start, goal)
                    animate = True
                    path_index = 0        

    dt = kello.tick(30) / 1000 
    last_move += dt

    keys = ui.key.get_pressed()
    if last_move >= move_delay:
        move_delay = 0.01
        if keys[ui.K_UP] and maze[py-1][px] == " ":
            py -= 1
            last_move = 0
        if keys[ui.K_DOWN] and maze[py+1][px] == " ":
            py += 1
            last_move = 0
        if keys[ui.K_RIGHT] and maze[py][px+1] == " ":
            px += 1
            last_move = 0
        if keys[ui.K_LEFT] and maze[py][px-1] == " ":
            px -= 1
            last_move = 0              

    ikkuna.fill((255, 255, 255))
    for y in range(HEIGHT):
        for x in range(WIDTH):
            if maze[y][x] == "#":
                ui.draw.rect(ikkuna, (0,0,0), (TIMES_BIGGER*x, TIMES_BIGGER*y, TIMES_BIGGER, TIMES_BIGGER))

    if ai:
        if animate and path_index < len(path):
            path_index += 1
        for x, y in path[:path_index]:
            ui.draw.rect(ikkuna, (0,255,0), (TIMES_BIGGER*x, TIMES_BIGGER*y, TIMES_BIGGER, TIMES_BIGGER))

    ui.draw.rect(ikkuna, (0,0,255), (TIMES_BIGGER*start[0], TIMES_BIGGER*start[1], TIMES_BIGGER, TIMES_BIGGER))
    ui.draw.rect(ikkuna, (255,0,0), (TIMES_BIGGER*goal[0], TIMES_BIGGER*goal[1], TIMES_BIGGER, TIMES_BIGGER))

    ui.draw.rect(ikkuna, (255, 0, 255), (TIMES_BIGGER*px, TIMES_BIGGER*py, TIMES_BIGGER, TIMES_BIGGER))

    if (px, py) == goal:
        maze = [["#" for _ in range(WIDTH)] for _ in range(HEIGHT)]
        makeMaze(*start)
        if ai:
            path = solveMaze(start, goal)
            animate = True
        path_index = 0
        px, py = 1, 1
        move_delay = 1

    ui.display.flip()
    kello.tick(30)