## PathFinder Maze 1.0
# Tässä pelissä sinun täytyy. No... Varmaan arvaat jo nimestä! (Mennä labyrinttien läpi)
# Saat laitettua AI-ominaisuuden päälle joka ratkoo kaikki labyrintit puolestasi.
# Ennen kuin pääset pelaamaan niin: Asenna pygame (Ainut kirjasto joka pitää asentaa) ja sinun täytyy tietää ohjeet!

# 1. Pygame
- Linux:
python3 -m venv env 
pip install pygame

- Windows:
py -m venv env 
pip install pygame

- MacOS:
python3 -m venv env 
pip install pygame

## Eikö olekin liian helppoa?

# 2. Ohjeet! (Varmasti kaikkien mielestä paras osuus READMEssä!)
- Liikut nuolinäppäimistä (Jos et tiennyt niin oikeasta nuolesta oikealle, vasemmasta vasemmalle, jne.)
- Kaikki resettautuu painamalla R. (Labyrinttikin generoidaan uudestaan)
- Saat vaihdettua AI-tilan päälle ja pois painamalla A.

## Ja siinä se oli. Nyt pelaamaan! (Jos osaat ajaa ohjelman. Minä en sitä nimittäin kerro! MUAHHAHHAHHAA!)