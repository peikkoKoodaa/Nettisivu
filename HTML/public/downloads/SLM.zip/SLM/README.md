## SLM-AI
# Tämä on pieni kielimalli (Small Language Model) joka on.. Aika tyhmä mutta tämä on vasta testi.

- Ensin sinun täytyy asentaa kaikki kirjastot pipillä (Sinulla pitää tietenkin olla pip joten asennetaan sekin!)

# 1. Asennetaan pip:
- Linux:
tarkista onko pip asennettu komennolla: pip --version
- Jos tulee virhe niin: sudo apt install python3-pip

- Windows:
tarkista onko pip asennettu komennolla: pip --version
- Jos tulee virhe niin lataa python uudestaan!

- MacOS:
tarkista onko pip asennettu komennolla: python3 -m pip --version
- Jos tulee virhe niin täytyy asentaa pip Homebrewillä
- Jos et ole asentanut Homebrew'tä niin: /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
Seuraavana: python3 -m ensurepip --upgrade

# 2. Asennetaan kirjastot! :
- Linux:
cd (Paikka missä tämä on)
sudo apt update && sudo apt install espeak-ng libespeak1 python3-venv
python3 -m venv venv
source venv/bin/activate
pip install pyttsx3 torch matplotlib

- Windows:
cd (Paikka missä tämä on)
python -m venv venv
venv\Scripts\activate
pip install pyttsx3 pypiwin32 torch matplotlib

- MacOS:
cd (Paikka missä tämä on)
python3 -m venv venv
source venv/bin/activate
pip install pyttsx3 torch matplotlib

# 3. Käynnistetään äly! :
- Linux:
cd (Paikka missä tämä on)
source venv/bin/activate
python3 SLM.py

- Windows:
cd (Paikka missä tämä on)
venv\Scripts\actvate
python SLM.py

- MacOS:
cd (Paikka missä tämä on)
source venv/bin/activate
python3 SLM.py

## Homma on valmis!