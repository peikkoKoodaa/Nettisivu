import pyttsx3
from time import sleep, strftime, perf_counter
import torch
import torch.nn as nn
import random
import os
import sys
import threading
import matplotlib.pyplot as plt

puhuja = pyttsx3.init()
äänet = puhuja.getProperty("voices")
puhuja.setProperty("voice", äänet[37].id)

def sano(sanottava, nimi="AI", odotus=0):
    print(f"{nimi}: {sanottava}")
    puhuja.say(sanottava)
    puhuja.runAndWait()
    sleep(odotus)

lataus = [
    "|",
    "/",
    "-",
    "\\"
]

onko_ladattu = False

def lataa():
    global lataus
    global onko_ladattu

    while not onko_ladattu:
        for lataa in lataus:
            print(lataa, end="\r")
            sleep(0.1)
            if onko_ladattu:
                break    

datafile = "data.txt"
mallifile = "SLM_2.0.pth"

# Laitteet: cuda ja cpu
laite = "cuda" if torch.cuda.is_available() else "cpu"
sano(f"Laite: {laite.upper()}.")

# CPU-optimoinnit
if laite == "cpu":
    torch.set_num_threads(4)
    torch.backends.mkldnn.enabled = False
    torch.set_flush_denormal(True)
    torch.set_grad_enabled(True)
    torch.set_default_dtype(torch.float32)
    
# GPU-optimoinnit    
if laite == "cuda":
    torch.set_float32_matmul_precision("medium")

TRAIN_CONTEXT = 256
GENERATE_CONTEXT = 2048

def encode(s):
    return list(s.encode("utf-8"))

def decode(tokens):
    return bytes(tokens).decode("utf-8", errors="ignore")

if not os.path.exists(datafile):
    sano("Datasettiä ei ole olemassa tai polku on väärä!")
    sys.exit()

def stream_batch(batch_size=64, context=TRAIN_CONTEXT, split="train"):
    xs, ys = [], []

    filesize = os.path.getsize(datafile)

    if split == "train":
        start = 0
        end = int(filesize * (1 - VALID_SPLIT))
    else: 
        start = int(filesize * (1 - VALID_SPLIT))
        end = filesize

    with open(datafile, "rb") as f:
        f.seek(random.randint(start, max(start, end - 4096)))
        buffer = f.read(4096)
        tokens = list(buffer)

        if len(tokens) < context + 1:
            return stream_batch(batch_size, context, split)

        for _ in range(batch_size):
            i = random.randint(0, len(tokens) - context - 1)
            xs.append(tokens[i:i+context])
            ys.append(tokens[i+1:i+context+1])

    xs = torch.tensor(xs, dtype=torch.long)
    ys = torch.tensor(ys, dtype=torch.long)
    return xs, ys
  
vocab_size = 256

context = 1024
embed = 384
epochs = 2000      
dropout = 0.1
heads = 8
layers = 6
train_losses = []
val_losses = []

VALID_SPLIT = 0.02
WARMUP_EPOCHS = 200
EVAL_EVERY = 10
VAL_BUFFER = None

class TransformerBlock(nn.Module):
    def __init__(self, embed, heads, dropout):
        super().__init__()
        self.attn = nn.MultiheadAttention(embed, heads, batch_first=True)
        self.ff = nn.Sequential(
            nn.Linear(embed, 3 * embed),
            nn.GELU(),
            nn.Linear(3 * embed, embed)
        )
        self.ln1 = nn.LayerNorm(embed)
        self.ln2 = nn.LayerNorm(embed)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask):
        attn, _ = self.attn(x, x, x, attn_mask=mask)
        x = self.ln1(x + self.dropout(attn))
        x = self.ln2(x + self.dropout(self.ff(x)))
        return x    

class TransformerSLM(nn.Module):
    def __init__(self, vocab_size, embed, context, layers, heads):
        super().__init__()
        self.token = nn.Embedding(vocab_size, embed)
        self.pos = nn.Embedding(context, embed)

        self.blocks = nn.ModuleList([
            TransformerBlock(embed, heads, dropout)
            for _ in range(layers)
        ])

        self.fc = nn.Linear(embed, vocab_size, bias=False)
        self.fc.weight = self.token.weight

        self.register_buffer(
            "mask",
            torch.triu(
                torch.full((context, context), float("-inf")),
                diagonal=1
            )
        )

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        x = self.token(x) + self.pos(pos)

        mask = self.mask[:T, :T].to(x.device)

        for block in self.blocks:
            x = block(x, mask)

        return self.fc(x)

model = TransformerSLM(
    vocab_size=vocab_size,
    embed=embed,
    context=context,
    layers=layers,
    heads=heads
).to(laite)
optimizer = torch.optim.AdamW(
    model.parameters(), 
    lr=0.0006, 
    weight_decay=0.1
)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
    optimizer,
    T_max=epochs
)
loss_fn = nn.CrossEntropyLoss()
min_loss = 0.25

def get_val_buffer(size=4096):
    global VAL_BUFFER
    if VAL_BUFFER is None:
        filesize = os.path.getsize(datafile)
        start = int(filesize * (1 - VALID_SPLIT))
        with open(datafile, "rb") as f:
            f.seek(start)
            VAL_BUFFER = list(f.read(size))
    return VAL_BUFFER

@torch.no_grad()
def evaluate(model, steps=20):
    model.eval()
    losses = []
    tokens = get_val_buffer()

    for _ in range(steps):
        xs, ys = [], []
        for _ in range(16):
            i = random.randint(0, len(tokens) - TRAIN_CONTEXT - 1)
            xs.append(tokens[i:i+TRAIN_CONTEXT])
            ys.append(tokens[i+1:i+TRAIN_CONTEXT+1])

        x = torch.tensor(xs, dtype=torch.long).to(laite)
        y = torch.tensor(ys, dtype=torch.long).to(laite)

        logits = model(x)
        loss = loss_fn(logits.view(-1, vocab_size), y.view(-1))
        losses.append(loss.item())

    model.train()
    return sum(losses) / len(losses)    

if os.path.exists(mallifile):
    sano("Malli on opetettu. Ladataan malli.")

    checkpoint = torch.load(mallifile, map_location=laite)

    context = checkpoint["context"]
    embed   = checkpoint["embed"]
    layers  = checkpoint["layers"]
    heads   = checkpoint["heads"]
    vocab_size = vocab_size
    model = TransformerSLM(
        vocab_size=vocab_size,
        embed=embed,
        context=context,
        layers=layers,
        heads=heads
    ).to(laite)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    sano(
        f"Ladattu malli (epoch {checkpoint['epoch']}, "
        f"loss {checkpoint['loss']:.4f})"
    )

    if checkpoint["loss"] > min_loss and False:
        torch.set_flush_denormal(True)

        sano("Jatketaan opetusta...")
        best_loss = checkpoint['loss']
        alku_epoch = checkpoint['epoch'] + 1
        best_val_loss = checkpoint['loss']
        fast_loss = best_val_loss
        patience = 200
        bad_epochs = 0
        val_history = []
        plt.ion()
        fig, ax = plt.subplots()
        train_line, = ax.plot([], [], label="train")
        val_line,   = ax.plot([], [], label="val")
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Loss")
        ax.legend()

        model.train()
        for epoch in range(alku_epoch, alku_epoch + 500):
            x, y = stream_batch(batch_size=16)
            x = x.to(laite, non_blocking=True)
            y = y.to(laite, non_blocking=True)
            logits = model(x)
            loss = loss_fn(logits.view(-1, vocab_size), y.view(-1))

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()

            if epoch < 50:
                for g in optimizer.param_groups:
                    g['lr'] = 0.0006 * (epoch + 1) / 50

            train_losses.append(loss.item())
            if epoch % EVAL_EVERY == 0:
                fast_loss = evaluate(model, steps=2)
                val_history.append(fast_loss)
                if len(val_history) > 5:
                    val_history.pop(0)
                avg_val_loss = sum(val_history) / len(val_history)
            else:
                avg_val_loss = best_val_loss        

            if epoch % EVAL_EVERY == 0:
                val_loss = evaluate(model, steps=5)
                val_losses.append(val_loss)
                print(
                    f"Epoch {epoch + 1} | "
                    f"train {loss.item():.4f} | "
                    f"val {val_loss:.4f}"
                )
            if epoch >= WARMUP_EPOCHS and epoch % EVAL_EVERY == 0 and best_val_loss == float("inf"):
                best_val_loss = avg_val_loss
                bad_epochs = 0    
            if epoch >= WARMUP_EPOCHS and epoch % EVAL_EVERY == 0:    
                if avg_val_loss < best_val_loss - 0.0005:
                    best_val_loss = avg_val_loss
                    bad_epochs = 0
                    torch.save({
                        "model": model.state_dict(),
                        "loss": avg_val_loss,
                        "epoch": epoch,
                        "context": context,
                        "embed": embed,
                        "layers": layers,
                        "heads": heads
                    }, mallifile)
                else:
                    bad_epochs += 1
                    if bad_epochs >= patience:
                        sano("Val-loss ei parane - lopetetaan opetus!")
                        break

            train_line.set_xdata(range(len(train_losses)))
            train_line.set_ydata(train_losses)
            val_line.set_xdata([i*EVAL_EVERY for i in range(len(val_losses))])
            val_line.set_ydata(val_losses)
            ax.relim()
            ax.autoscale_view()
            plt.pause(0.01)           

        sano(f"Jatko-opetuksen paras loss: {best_val_loss:.4f}")

else:
    koko_alku = perf_counter()
    torch.set_flush_denormal(True)

    sano("Mallia ei ole opetettu tai mallin lataustiedosto on väärä!")
    sano(f"Mallin opetus aloitetaan aikaan {strftime('%H:%M:%S')}!")
    best_loss = float("inf")
    best_val_loss = float("inf")
    fast_loss = best_val_loss
    patience = 200
    bad_epochs = 0
    model.train()
    val_history = []
    plt.ion()
    fig, ax = plt.subplots()
    train_line, = ax.plot([], [], label="train")
    val_line,   = ax.plot([], [], label="val")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.legend()    
    for epoch in range(epochs):
        alku = perf_counter()
        x, y = stream_batch(batch_size=16)
        x = x.to(laite, non_blocking=True)
        y = y.to(laite, non_blocking=True)
        logits = model(x)
        loss = loss_fn(
            logits.view(-1, vocab_size),
            y.view(-1)
        )

        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()
        loppu = perf_counter()
        
        kesto = loppu - alku
        sekunnit = int(kesto)
        minuutit = sekunnit // 60
        tunnit = minuutit // 60
        epochs_jäljellä = epochs - epoch - 1
        jäljellä = kesto * epochs_jäljellä

        j_sec = int(jäljellä)
        j_min = j_sec // 60
        j_hour = j_min // 60

        if epoch < 50:
            for g in optimizer.param_groups:
                g['lr'] = 0.0006 * (epoch + 1) / 50
        
        train_losses.append(loss.item())
        if epoch % EVAL_EVERY == 0:
            fast_loss = evaluate(model, steps=2)
            val_history.append(fast_loss)
            if len(val_history) > 5:
                val_history.pop(0)
            avg_val_loss = sum(val_history) / len(val_history)
        else:
            avg_val_loss = best_val_loss     

        if epoch % EVAL_EVERY == 0:
            val_loss = evaluate(model, steps=5)
            val_losses.append(val_loss)
            print(
                f"Epoch {epoch + 1} | "
                f"train {loss.item():.4f} | "
                f"val {val_loss:.4f}"
            )
        if epoch >= WARMUP_EPOCHS and epoch % EVAL_EVERY == 0 and best_val_loss == float("inf"):
            best_val_loss = avg_val_loss
            bad_epochs = 0    
        if epoch >= WARMUP_EPOCHS and epoch % EVAL_EVERY == 0:    
            if avg_val_loss < best_val_loss - 0.0005:
                best_val_loss = avg_val_loss
                bad_epochs = 0
                torch.save({
                    "model": model.state_dict(),
                    "loss": avg_val_loss,
                    "epoch": epoch,
                    "context": context,
                    "embed": embed,
                    "layers": layers,
                    "heads": heads
                }, mallifile)
            else:
                bad_epochs += 1
                if bad_epochs >= patience:
                    sano("Val-loss ei parane - lopetetaan opetus!")
                    break

        train_line.set_xdata(range(len(train_losses)))
        train_line.set_ydata(train_losses)
        val_line.set_xdata([i*EVAL_EVERY for i in range(len(val_losses))])
        val_line.set_ydata(val_losses)
        ax.relim()
        ax.autoscale_view()
        plt.pause(0.01)            

    koko_loppu = perf_counter()
    sano(f"Opetuksessa kesti {koko_loppu - koko_alku:.3f} sekuntia!")
    sano(f"Opetuksen paras loss oli {best_val_loss:.4f}!")

def generate(start=None, length=100, temperature=0.65, top_k=40, top_p=0.9, rep_penalty=1.1):
    model.eval()
    entropys = []
    if start is None or start == "":
        tokens = [random.randint(0, vocab_size - 1)]
    else:    
        tokens = encode(start)
        if not tokens:
            tokens = [random.randint(0, vocab_size - 1)]
    newline_token = ord("\n")

    for _ in range(length):
        context_tokens = tokens[-GENERATE_CONTEXT:]
        x = torch.tensor([context_tokens], dtype=torch.long).to(laite)
        logits = model(x)
        logits = logits[:, -1, :]
        
        for t in set(tokens[-128:]):
            logits[0, t] /=rep_penalty

        logits = logits / temperature
        probs = torch.softmax(logits, dim=-1).squeeze(0)
        entropys.append(-torch.sum(probs * torch.log(probs + 1e-9)).item())
        if entropys[-1] < 0.08:
            temperature *= 1.05
        elif entropys[-1] > 0.4:
            temperature *= 0.95
        temperature = max(0.2, min(temperature, 0.8))        

        if top_k is not None:
            k = min(top_k, len(probs))
            top_probs, top_idx = torch.topk(probs, k)
        else:
            top_probs, top_idx = probs, torch.arange(len(probs))

        if top_p is not None and len(top_probs) > 1:
            sorted_probs, sorted_idx = torch.sort(top_probs, descending=True)
            cumulative_probs = torch.cumsum(sorted_probs, dim=0)
            mask = cumulative_probs <= top_p
            mask[0] = True 
            top_idx = top_idx[sorted_idx[mask]]
            top_probs = sorted_probs[mask]

        top_probs = top_probs / top_probs.sum()
        sample_idx = torch.multinomial(top_probs, 1).item()
        next_token = int(top_idx[sample_idx].item())
        tokens.append(next_token)

        if newline_token is not None and next_token == newline_token:
            break

    return decode(tokens), sum(entropys) / len(entropys)

tyylit = [
    "Ole hauska ja kekseliäs",
    "Vastaa lyhyesti ja ytimekkäästi",
    "Ole asiantuntija ja selitä yksityiskohtaisesti",
    "Ole ystävällinen ja empaattinen"
]

tapa = random.choice(tyylit)

def vastaa(user_input, show_system_input=False, tapa=None):
    if random.random() < 0.2:
        tapa = random.choice(tyylit)
    prompt = f"Tyyli: {tapa}\nKysymys: {user_input}\nVastaus:"
    if "hauska" in tapa:
        temp, top_k, top_p, lenght = 0.6, 30, 0.9, 450
    elif "asiantuntija" in tapa:
        temp, top_k, top_p, lenght = 0.3, 15, 0.95, 550
    elif "lyhyesti" in tapa:
        temp, top_k, top_p, lenght = 0.55, 30, 0.85, 400     
    else:
        temp, top_k, top_p, lenght = 0.45, 20, 0.85, 450    

    with torch.inference_mode():
        sanottu, entropy = generate(prompt, length=lenght, temperature=temp, top_k=top_k, top_p=top_p, rep_penalty=0.95)

    if entropy < 0.5:
        varmuus = "Olen aika varma vastauksestani."
    elif entropy < 1:
        varmuus = "En ole täysin varma, mutta yritän parhaani."
    else:
        varmuus = "Hmm... En ole kovin varma tästä, mutta kokeillaan silti!"

    if show_system_input:
        sano(f"System input: {tapa}.")
        sano(f"varmuustaso: {varmuus}. (Entropy: {entropy:.4f})")

    return sanottu.split("Vastaus:")[-1].strip()    

# Päälooppi
while True:
    user_input = input("Sano mitä tahansa: ")
    onko_ladattu = False
    threading.Thread(target=lataa).start()
    vastaus = vastaa(user_input, tapa=tapa)
    onko_ladattu = True
    sano(vastaus)
    print("---------------------")