### Hyppelypeli

## Asenna kirjastot

# Windows
- Asenna Python jos sitä ei vielä ole (Microsoft Store)
- Aja terminaalissa: pip install pygame

# Linux
- Asenna Python jos sitä ei vielä ole ajamalla: sudo apt install python
- Aja terminaalissa: pip install pygame --break-system-packages

# MacOS
- Asenna Homebrew Pythonin latausta varten jos ei vielä ole:
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    echo >> /Users/userprofile/.zprofile
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> /Users/userprofile/.zprofile
    eval "$(/opt/homebrew/bin/brew shellenv)"
    brew update
- Asenna Python jos sitä ei vielä ole ajamalla: brew install python
- Aja terminaalissa: pip install pygame

## Käynnistä peli

# Windows
- python (pelin/path)

# Linux
- python3 (pelin/path)

# MacOS
- python3 (pelin/path)