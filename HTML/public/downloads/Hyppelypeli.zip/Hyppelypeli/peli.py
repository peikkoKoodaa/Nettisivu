import pygame as pg

pg.init()

WIDTH, HEIGHT = 1280, 720
window = pg.display.set_mode((WIDTH, HEIGHT))

clock = pg.time.Clock()

playerTexture1 = pg.image.load("santa0Texture.png")
playerTexture2 = pg.image.load("santa1Texture.png")
groundTexture  = pg.image.load("groundTexture.png")
barrelTexture  = pg.image.load("barrelTexture.png")
skyTexture     = pg.image.load("skyTexture.png")

playerAnimationFrame = True
running = True
jumpedLastFrame = False
onGround = True

groundY = 542
velocityY = 0
x, y = 30, groundY
gravity = 0.4
bg1X = 0
bg2X = WIDTH

animationFrame = 0

class Barrel:
    def __init__(self, texture: pg.Surface, movespeed: int):
        self.texture   = texture
        self.movespeed = movespeed
        self.x         = WIDTH
        self.angle     = 0

    def update(self):
        self.angle += self.movespeed
        if self.angle >= 360:
            self.angle = 0
        self.x -= self.movespeed
        if self.x <= 0:
            self.movespeed += 1
            self.x = WIDTH

    def render(self):
        window.blit(pg.transform.rotate(pg.transform.scale(self.texture, (50, 50)), self.angle), (self.x, groundY))

barrel = Barrel(barrelTexture, 5)

testing = True
hacks = True

barrel.x = x
velocityY = -10
framesInAir = 0
while testing:
    velocityY += gravity
    y += velocityY
    if velocityY > 0 and pg.Rect(x, y, 50, 50).colliderect(barrel.x, groundY, 50, 50):
        testing = False
    framesInAir += 1

barrel.x = WIDTH
velocityY = 0


while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                running = False

            if event.key == pg.K_UP or event.key == pg.K_SPACE:
                if not jumpedLastFrame and onGround:
                    velocityY = -10
                    jumpedLastFrame = True
        
        if event.type == pg.KEYUP:
            if event.key == pg.K_UP or event.key == pg.K_SPACE:
                jumpedLastFrame = False

    if hacks and (barrel.x <= framesInAir * barrel.movespeed):
        if onGround:
            velocityY = -10

    animationFrame += 1

    if animationFrame >= 10:
        playerAnimationFrame = not playerAnimationFrame
        animationFrame = 0

    onGround = False

    velocityY += gravity
    y += velocityY

    if y > groundY:
        y = groundY
        onGround = True

    barrel.update()

    bg1X -= 4
    bg2X -= 4

    if bg1X <= -WIDTH:
        bg1X = WIDTH

    if bg2X <= -WIDTH:
        bg2X = WIDTH

    if onGround and pg.Rect(barrel.x, groundY, 50, 50).colliderect(pg.Rect(x, y, 50, 50)):
        running = False

    window.fill((40, 214, 236))
    window.blit(pg.transform.scale(skyTexture, (WIDTH, HEIGHT - 256)), (bg1X, 0))
    window.blit(pg.transform.scale(skyTexture, (WIDTH, HEIGHT - 256)), (bg2X, 0))
    if     playerAnimationFrame: window.blit(pg.transform.scale(playerTexture1, (50, 50)), (x, y))
    if not playerAnimationFrame: window.blit(pg.transform.scale(playerTexture2, (50, 50)), (x, y))

    barrel.render()

    window.blit(pg.transform.scale(groundTexture, (WIDTH, 256)), (bg1X, HEIGHT - 256))
    window.blit(pg.transform.scale(groundTexture, (WIDTH, 256)), (bg2X, HEIGHT - 256))

    pg.display.flip()
    clock.tick(60)

pg.quit()
exit()